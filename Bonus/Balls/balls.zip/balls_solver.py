#!/bin/python3
# -*- encoding: utf-8 -*-

def solve(weigh):
    heavier = weigh([1], [2])
    if heavier == 'left':
        return (1,'+')
    elif heavier == 'right':
        return (2, '+')
    else:
        return (12, '-')