import unittest
from linear_algebra.euclidean import EuclideanVector


class TestEuclideanVector(unittest.TestCase):

    def test_str(self):
        self.assertEqual("Vector(10, 20)", str(EuclideanVector(10, 20)))
        self.assertEqual("Vector(1.1, 2.2)", str(EuclideanVector(1.1, 2.2)))

    def test_eq(self):
        self.assertTrue(EuclideanVector(1, 2) == EuclideanVector(1, 2))
        self.assertFalse(EuclideanVector(1, 2) == EuclideanVector(1, 0))
        self.assertFalse(EuclideanVector(1, 2) == 2)

    def test_add(self):
        self.assertEqual(EuclideanVector(3, 4), EuclideanVector(1, 1) + EuclideanVector(2, 3))
        with self.assertRaises(TypeError):
            EuclideanVector(1, 1) + 2

    def test_euclidean_norm(self):
        self.assertEqual(2, EuclideanVector(2, 0).euclidean_norm())
        self.assertEqual(2**0.5, EuclideanVector(1, 1).euclidean_norm())
