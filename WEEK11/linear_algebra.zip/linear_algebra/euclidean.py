"""Linear algebra sctructures (currently only vectors) in Euclidean space"""

VERSION = "0.1"

# Error classes

class NonPositiveValueError(ValueError):
    """ValueError where the value is non-positive"""


# Vector classes

class EuclideanVector:
    """2d vector in Euclidean space"""

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def euclidean_norm(self):
        """Return the euclidean distance from origin which is equal to euclidean norm"""
        return (self.x**2 + self.y**2)**0.5

    def __str__(self):
        return f"Vector({self.x}, {self.y})"

    def __eq__(self, other):
        if not isinstance(other, EuclideanVector):
            return False

        return self.x == other.x and self.y == other.y

    def __add__(self, other):
        if not isinstance(other, EuclideanVector):
            raise TypeError(f"Second operand has incorrect type: {type(other)}")

        return EuclideanVector(self.x + other.x, self.y + other.y)


class YVector(EuclideanVector):
    """2d vector in Euclidean space where x=0"""

    def __init__(self, y):
        super().__init__(x=0, y=y)


class PositiveYVector(YVector):
    """2d vector in Ecludiean space where x=0 and y>0"""

    def __init__(self, y):
        if y <= 0:
            raise NonPositiveValueError(f"Y is not positive: {y}")

        super().__init__(y)
